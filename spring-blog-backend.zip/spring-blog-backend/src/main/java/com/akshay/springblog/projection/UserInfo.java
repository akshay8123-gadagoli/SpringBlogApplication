package com.akshay.springblog.projection;

public interface UserInfo {
    
    Long getId();
    String getName();
    String getUsername();
}
