package com.akshay.springblog.model;

public enum RoleName {
    ROLE_USER, ROLE_ADMIN,
}
