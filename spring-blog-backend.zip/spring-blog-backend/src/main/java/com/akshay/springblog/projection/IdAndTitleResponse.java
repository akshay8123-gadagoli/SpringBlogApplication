package com.akshay.springblog.projection;

public interface IdAndTitleResponse {
    Long getId();
    String getTitle();
}
