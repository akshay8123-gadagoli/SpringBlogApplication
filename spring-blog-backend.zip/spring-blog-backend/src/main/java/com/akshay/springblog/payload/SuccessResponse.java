package com.akshay.springblog.payload;

public class SuccessResponse extends AppResponse {

    public SuccessResponse(String message) {
        super(true, message);

    }

}
