package com.akshay.springblog.projection;

public interface TagsOrCategoriesResponse {
    Long getId();
    String getTitle();
    String getSlug();
}
