package com.akshay.springblog.model;

public enum StatusName {
    PUBLIC,PRIVATE
}
