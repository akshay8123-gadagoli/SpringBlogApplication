package com.akshay.springblog.util;

public interface AppConstant {
    String DEFAULT_PAGE_NUMBER = "0";
    String DEFAULT_PAGE_SIZE = "20";
    
    String MAX_PAGE_SIZE = "50";
}
